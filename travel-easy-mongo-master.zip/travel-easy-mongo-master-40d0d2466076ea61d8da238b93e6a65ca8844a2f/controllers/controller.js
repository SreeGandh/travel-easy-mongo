const services = require('../services/services')
const constants = require('../constants/constants')

createVisaApplication = async(req , resp, next) => {
    let statusCode = 200
    let response = {}
    credentials = req.body
    //  console.log("credentials" , credentials)

    try {
        if(!(credentials.passport_id &&
           credentials.visa_type &&
           credentials.destination &&
           credentials.expected_date_of_travel &&
           credentials.reason_of_travel
           )){
               throw new error("Details missing")
           }

       response =  await services.createVisaApplication(credentials)
    //    console.log(response)
    }
    catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[01],
        }
        statusCode = 412
    }
    resp.status(statusCode).send(response)
}

getApplicationStatus = async(req, resp, next) => {
    let response = {}
    let status_code = 200
    try{
        if(!req.params.id){
            throw new error ("parameter missing")
        }
        // console.log(req.params.id)
        response = await services.getApplicationStatus(req.params.id)
        // console.log(response)
        if(response.code === ERROR_CODES[2]){
            status_code = 404
        }else if(response.isSuccess === false){
            status_code = 400
        }
    }
    catch(err){
        status_code = 400
    }
    resp.status(status_code).send(response)
}

getApplicationsByStatus = async (req, resp, next) => {
    let response = {}
    let statusCode = 200

    if(!req.query.status){
        response = {
            isSuccess : false,
            code : ERROR_CODES[8],
            error : "Details missing , try again !"
        }
        statusCode = 412
    }else {
        response = await services.getApplicationsByStatus(req.query.status)
    }
    resp.status(statusCode).send(response)

}

getApplicationDetails = async (req, resp, next) => {
    let response = {}
    let status_code = 200
    try{
        if(!req.params.id){
            throw new error ("parameter missing")
        }
        // console.log(req.params.id)
        response = await services.getApplicationDetails(req.params.id)
        if(response.code === constants.ERROR_CODES[2]){
            status_code = 404
        }else if(response.isSuccess === false){
            status_code = 400
        }
    }
    catch(err){
        status_code = 400
    }
    resp.status(status_code).send(response)
}

modifyApplicationStatus = async(req, resp, next) => {
    let response = {}
    let status_code = 200
    credentials = req.body
    try {
        if(!(credentials.status)){
               throw new error("Details missing")
        }

        response = await services.modifyApplicationStatus(req.params.id, req.body.status)
        if(response.code === constants.ERROR_CODES[2]){
            status_code = 404
        }else if(response.isSuccess === false){
            status_code = 400
        }
    }
    catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4]
        }
        status_code = 412
    }
    resp.status(status_code).send(response)
}

uploadDocuments = async(req, resp, next) => {
    let response = {}
    let status_code = 200

    //console.log(req)
    if (!req.files || Object.keys(req.files).length === 0) {
        // console("no file")
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[5],
            data : "no documents uploaded"
        }
        resp.status(400).send(response)
     }
     else{
        response = await services.uploadDocuments(req.params.id ,req.files)

        if(response.code === constants.ERROR_CODES[6]){
            status_code = 401
        }else if(response.isSuccess === false){
            status_code = 400
        }
        resp.status(status_code).send(response)
     }

     
}


downloadDocument = async(req, resp , next) => {
    let response = {}
    
    response = await services.downloadDocuments(req.params.id)
    
    // console.log(response)

    if(response.isSuccess){
        resp.status(200).download(response.file_url)
    }else{
        resp.status(404).send(response)
    }
}

module.exports = {
    createVisaApplication,
    getApplicationStatus,
    getApplicationsByStatus,
    getApplicationDetails,
    modifyApplicationStatus,
    uploadDocuments,
    downloadDocument
}