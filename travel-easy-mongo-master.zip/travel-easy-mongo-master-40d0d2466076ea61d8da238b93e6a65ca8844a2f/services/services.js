const mongoUtils = require('../utils/mongoUtil')
const visaModel = require('../models/visaApplication')
const SHA256 = require("crypto-js/sha256");
const constants = require('../constants/constants');
const helper = require('../utils/helpers');
const passportModel = require('../models/passport')
const fs = require('fs')

createVisaApplication = async(applicationDetails) => {

    let response = {}
    try{
       
        date = applicationDetails.expected_date_of_travel.split('/')
        expectedDate = new Date(parseInt(date[2]),parseInt(date[1])-1,parseInt(date[0])+1)
        applicationDetails.expected_date_of_travel = expectedDate
    

         mostRecentApplication = await helper.mostRecentApplication()

        // console.log(mostRecentApplication)
        //  console.log(mostRecentApplication.length)
        if(mostRecentApplication.length != 0){
            daysBetween  = helper.getDifferenceBetweenDays(Date.now(),mostRecentApplication[0].last_modified)
        }else{
            daysBetween = parseInt(process.env.VISA_REAPPLICATION_DURATION) + 1
        }
        // console.log(daysBetween)

        if (daysBetween <= process.env.VISA_REAPPLICATION_DURATION){
            response = {
                isSuccess : false,
                code : constants.ERROR_CODES[7]
            }
        }else{
            // console.log(applicationDetails)
            result = await mongoUtils.insert(visaModel, applicationDetails)
            // console.log(result)
            if(result === null){
                throw new error("cannot insert document")
            }
            response = {
                isSuccess : true,
                code : constants.SUCCESS_CODES[1],
                data : result
            }
        }
    }
    catch(err){
        response = {
            isSuccess : false ,
            code : constants.ERROR_CODES[3]
        }
    }
    // console.log(response)
    return response
}

getApplicationStatus = async(id) => {
    let response = {}

    try{
        filterQuery = {application_id : id}
        // console.log(filterQuery)

        result = await mongoUtils.findOne(visaModel, filterQuery)

        if(result === undefined){
            throw new error("no such id")
        }
        data = {
            id : result.application_id,
            status : result.status,
            destination : result.destination,
            visa_type : result.visa_type
        }

        if(data.status == constants.APPLICATION_STATUS_CODES[2]){
            data.file_url = result.file_url,
            data.upload_within =  new Date(result.last_modified.getTime() + (parseInt(process.env.FILE_UPLOAD_EXPIRATION_DURATION)*24*60*60*1000))

        }else if(data.status == constants.APPLICATION_STATUS_CODES[6]){
            data.active_till = result.active_till
        }

        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[1],
            data : data
        }
        // console.log(response)

    }
    catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[2]
        }
    }
    return response
}

getApplicationsByStatus = async(statusCode) => {
    response = {}
    try{
        findQuery = {status : constants.APPLICATION_STATUS_CODES[statusCode]}
        if(findQuery.status === undefined){
            throw new error("wrong status code")
        }
        result = await mongoUtils.find(visaModel, findQuery)
        
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[2],
            data : result
        }
    }catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[3]
        }
    }
    return response
}

getApplicationDetails = async(id) => {
    let response = {}
    try{
        filterQuery = {application_id : id}


        result = await mongoUtils.findOne(visaModel, filterQuery)

        if(result === undefined){
            throw new error("no such id")
        }

        passportFilter = {id : result.passport_id}
        //  console.log(passportFilter)
        passportData = await mongoUtils.findOne(passportModel, passportFilter)
        //  console.log(passportData)
        if(passportData === undefined){
            throw new error("no passport with such id")
        }

       
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[2],
            application_data : result,
            passport_data : passportData
        }

    }catch(err){
        response = {
            isSuccess : false,
            code  : constants.ERROR_CODES[3]
        }
    }
    return response
}

modifyApplicationStatus = async(id, status) => {

    try{
        //console.log(id , status)
        filterQuery = {
            application_id : id
        }

        result = await mongoUtils.findOne(visaModel, filterQuery)

        updateQuery = {
            $set :{
                status : constants.APPLICATION_STATUS_CODES[parseInt(status)],
                last_modified : new Date(Date.now())
            }
        }

        if(parseInt(status) === 2) {
            updateQuery = {
                $set :{
                    status : constants.APPLICATION_STATUS_CODES[parseInt(status)],
                    file_url : SHA256(result.application_id).toString(),
                    last_modified : new Date(Date.now())
                }
            }
        }else if(parseInt(status) === 6) {
            daysToBeAdded = constants.VISA_TYPES[result.visa_type]
            newDate = new Date(Date.now())
            date = new Date(newDate.getTime() + (parseInt(daysToBeAdded)*24*60*60*1000))
            updateQuery = {
                $set :{
                    status : constants.APPLICATION_STATUS_CODES[parseInt(status)],
                    active_till : date,
                    last_modified : new Date(Date.now())
                }
            }
        }

        updateResult = await mongoUtils.findOneAndUpdate(visaModel, filterQuery, updateQuery)

        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[3],
            data : []
        }

    }catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4]
        }
    }
    return response
}

uploadDocuments = async(id, file) => {
    let response = {}
    try {
        let sampleFile = file.sampleFile

        filterQuery = {
            file_url : id
        }

        // console.log(filterQuery)
        let result = await mongoUtils.findOne(visaModel,filterQuery)
        // console.log(result)
        if(result.status != constants.APPLICATION_STATUS_CODES[2]){

            response = {
                isSuccess : false,
                status : constants.ERROR_CODES[6],
                data : "sorry upload link expired "
            }
            return response

        }else{
            daysDifference = helper.getDifferenceBetweenDays(new Date(Date.now()), result.last_modified)
            // console.log(daysDifference)

            if(daysDifference > parseInt(process.env.FILE_UPLOAD_EXPIRATION_DURATION)){
                filterQuery = {
                    application_id : result.application_id
                }

                updateQuery = {
                    $set :{
                        status : constants.APPLICATION_STATUS_CODES[5],
                        last_modified : new Date(Date.now())
                    }
                }

                updateResult = await mongoUtils.findOneAndUpdate(visaModel, filterQuery, updateQuery)

                response = {
                    isSuccess : false,
                    code : constants.ERROR_CODES[6],
                    data : "sorry upload link expired "
                }

                return response
            }
        }

        let dir = './files/'+`${result.application_id}`
        //  console.log(dir)
        if (!fs.existsSync(dir)){
            fs.mkdirSync(dir);
        }
        // console.log(sampleFile)
        sampleFile.mv(dir+'/'+`${sampleFile.name}`)
        // sampleFile.forEach(files => {
        //     console.log(files)
        //     files.mv(dir+'/'+`${files.name}`)
        // })

        filterQuery = {
            application_id : result.application_id
        }

        updateQuery = {
            $set :{
                status : constants.APPLICATION_STATUS_CODES[4],
                last_modified : new Date(Date.now())
            }
        }
        // console.log(filterQuery , updateQuery)
        updateResult = await mongoUtils.findOneAndUpdate(visaModel, filterQuery, updateQuery)

        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[4],
            data : "documents uploaded successfully"
        }


    }catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[5],
            data : "document upload failure please try again"
        }
    }

    return response;
}

downloadDocuments = async(id) => {
    let response = {}
    try{
        filterQuery = {
            file_url : id
        }
    
        let result = await mongoUtils.findOne(visaModel,filterQuery)

        if(result === undefined){
            throw new error('no such id')
        }

        application_id = result.application_id

        folder_path = './files/'+`${application_id}`
        file_array = []
        fs.readdirSync(folder_path).forEach(file => {
        file_array.push(file)
    })
    response = {
        isSuccess : true,
        file_url : folder_path+'/'+file_array[0],
        code : constants.SUCCESS_CODES[5]
    }
    }catch(err){
        response = {
            isSuccess : false,
            data : "something went wrong",
            code : constants.ERROR_CODES[2]
        }
    }
    return response
}

module.exports = {
    createVisaApplication,
    getApplicationStatus,
    getApplicationsByStatus,
    getApplicationDetails,
    modifyApplicationStatus,
    uploadDocuments,
    downloadDocuments
}