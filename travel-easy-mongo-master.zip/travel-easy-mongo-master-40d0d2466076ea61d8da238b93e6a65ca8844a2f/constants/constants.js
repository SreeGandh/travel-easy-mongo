const GENDER = ["male", "female" ,"other"]
const VISA_TYPE = ["student", "work", "medical", "tourist", "bussiness"]

PASSPORT = [
        {
            name : "sreegandh",
            dob :  new Date().setFullYear(1998,10,5),
            gender : "male",
            address : "12 ,abc street,xyz",
            nationality : "indian",
            valid_upto : new Date().setFullYear(2025,12,10)
        },
        {
            name : "bhuvanesh",
            dob : new Date().setFullYear(1990,5,2),
            gender : "male",
            address : "12 ,abc street,xyz",
            nationality : "indian",
            valid_upto : new Date().setFullYear(2020,10,3)  
        },
        {
            name : "sowmitha",
            dob : new Date().setFullYear(1999,8,7),
            gender : "female",
            address : "10 ,abcd street,xyz",
            nationality : "indian",
            valid_upto : new Date().setFullYear(2021,2,5)
        },
        {
            name : "surenthar",
            dob : new Date().setFullYear(1989,9,9),
            gender : "male",
            address : "12 ,abc street,xyz",
            nationality : "indian",
            valid_upto : new Date().setFullYear(2019,10,1)
        }
]

const ROUTES = {
    VISA_APPLICATIONS : "/traveleasy/visa_application",
    VISA_APPLICATION : "/traveleasy/visa_application/:id",
    VISA_APPLICATION_STATUS : "/traveleasy/visa_application/:id/status",
    DOCUMENT_UPLOAD : "/traveleasy/visa_application/:id/documents"
}

    
const APPLICATION_STATUS_CODES = {
    01 : "READY FOR PASSPORT VERIFICATION",
    02 : "PASSPORT VERIFICATION COMPLETED , UPLOAD DOCUMENTS",
    03 : "PASSPORT VERIFICATION FAILURE",
    04 : "DOCUMENT UPLOAD SUCCESSFUL",
    05 : "DOCUMENT UPLOAD FAILURE ,LINK EXPIRED",
    06 : "VISA GRANTED",
    07 : "VISA APPLICATION REJECTED"
}
    
const ERROR_CODES = {
    01 : "ERROR WHILE RECEIVING APPLICATION",
    02 : "NO SUCH APPLICATION ID",
    03 : "SOMETHING WENT WRONG",
    04 : "ERROR WHILE UPDATING APPLICATION STATUS",
    05 : "DOCUMENT UPLOAD FAILURE",
    06 : "UPLOAD LINK EXPIRED",
    07 : "REAPPLICATION TIME REMAINING",
    08 : "PARAMETER MISSING"
}

const SUCCESS_CODES = {
    01 : "APPLICATION RECEIVED SUCCESSFULLY",
    02 : "DOCUMENTS FETCHED ACCORDING TO STATUS SUCCESSFULLY",
    03 : "APPLICATION STATUS UPDATED SUCCESSFULLY",
    04 : "DOCUMENTS UPLOADED SUCCESSFULLY",
    05 : "DOCUMENTS DOWNLOADED SUCCESSFULLY"
}

const VISA_TYPES = {
    medical : 10,
    tourist : 60,
    student : 1825,
    work : 1095,
    bussiness : 15
}
    
module.exports = {
    GENDER,
    VISA_TYPE,
    PASSPORT,
    ROUTES,
    SUCCESS_CODES,
    ERROR_CODES,
    APPLICATION_STATUS_CODES,
    VISA_TYPES
}

