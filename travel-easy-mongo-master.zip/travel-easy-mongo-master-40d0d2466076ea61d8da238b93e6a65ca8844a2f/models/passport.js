const mongoose = require('mongoose')
const short = require('shortid')
const constants = require('../constants/constants')

const passportModel = mongoose.Schema({
    id : {
        type : String,
        default : short.generate,
        required : true
    },
    name : {
        type : String,
        required : true
    },
    dob : {
        type : Date,
        required : true
    },
    gender : {
        type : String,
        enum : constants.GENDER
    },
    address : {
        type : String,
        required : true
    },
    nationality : {
        type : String,
        required : true
    },
    valid_upto : {
        type : Date,
        required : true
    }
}) 

module.exports = mongoose.model('passport', passportModel);