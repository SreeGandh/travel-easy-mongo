const sinon = require('sinon')
const expect = require('chai').expect
const mongoUtils = require('../utils/mongoUtil')
const constants = require('../constants/constants')
const services = require('../services/services')
const helpers  = require('../utils/helpers')
const MongoMemoryServer = require('mongodb-memory-server')
const mongoose = require('mongoose')
const visaModel = require('../models/visaApplication')
const superTest = require('supertest')
const server = require('../app')


date = new Date()
date.setFullYear(2020,9,10)
date.setHours(23,60,00,00)

var creationDocReq1 = {
    "passport_id" : "123",
    "visa_type" : "student",
    "destination" : "London",
    "expected_date_of_travel" : "10/10/2020",
    "reason_of_travel" : "studies"
} 

var creationDocReq2 = {
    "hao" : "afa",
    "expected_date_of_travel" : "10/10/2020"
}

var creationDocReq20 = {
    "hao" : "afa",
    "expected_date_of_travel" : date
}


var expectedResp2 = {
    isSuccess: false,
     code: 'SOMETHING WENT WRONG'
}


var creationDocReq10 = {
    "passport_id" : "123",
    "visa_type" : "student",
    "destination" : "London",
    "expected_date_of_travel" : date,
    "reason_of_travel" : "studies"
} 


var creationDocResp1 = {
    isSuccess : true,
    code : constants.SUCCESS_CODES[1],
    data : [{
        "application_id": "m-UCivXVm",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-13T14:33:01.473Z",
        "_id": "5f0c70ad7286d7e7ce9a901a",
        "passport_id": "123",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
    }]
}



var insertResp1 = {
    "application_id": "m-UCivXVm",
    "status": "READY FOR PASSPORT VERIFICATION",
    "last_modified": "2020-07-13T14:33:01.473Z",
    "_id": "5f0c70ad7286d7e7ce9a901a",
    "passport_id": "123",
    "visa_type": "student",
    "destination": "London",
    "expected_date_of_travel": date,
    "reason_of_travel": "studies",
    "__v": 0
}

var appStatusExpectedRes1 = {
    "isSuccess": true,
    "code": "APPLICATION RECEIVED SUCCESSFULLY",
    "data": {
        "id": "123",
        "status": "PASSPORT VERIFICATION COMPLETED , UPLOAD DOCUMENTS",
        "destination": "London",
        "visa_type": "student",
        "file_url": "0c68c72d6cc1a02812a52d1bf4ac18cd812582e490fe3ab45050a250e854c3e7",
        "upload_within": "2020-07-15T12:27:12.078Z",
        "passport_id" : "abcd"
    }
}

var appStatusExpectedRes2 = {
    isSuccess : false,
    code : constants.ERROR_CODES[2]
}

var appStatusRes1 = {
        "application_id": "123",
        "status": "READY FOR PASSPORT VERIFICATION",
        "destination": "London",
        "visa_type": "student",
        "file_url": "0c68c72d6cc1a02812a52d1bf4ac18cd812582e490fe3ab45050a250e854c3e7",
        "upload_within": "2020-07-15T12:27:12.078Z",
        "passport_id" : "abcd"
}

var appByStatus = [
    {
        "application_id": "b57IW9_LV",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-10T07:20:49.693Z",
        "_id": "5f0816d5831ef111e2feeff4",
        "passport_id": "XuCj6fp_F",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
    },
    {
        "application_id": "V7TNUUupp",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-10T09:09:26.446Z",
        "_id": "5f08307447998d1495fc213a",
        "passport_id": "XuCj6fp_F",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
    },
    {
        "application_id": "yob6saMhP",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-10T09:11:29.739Z",
        "_id": "5f0830c531b80c14b60f009b",
        "passport_id": "XuCj6fp_F",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
    },
    {
        "application_id": "vV53Jcf4v",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-10T13:48:33.025Z",
        "_id": "5f08730c3dca341c4dbd21d5",
        "passport_id": "zfc5p42kTE",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
    }
]

var appByStatusResp1 = {
    "isSuccess": true,
    "code": "DOCUMENTS FETCHED ACCORDING TO STATUS SUCCESSFULLY",
    data : appByStatus
}

var appByStatusResp2 = {
    isSuccess : false,
    code : constants.ERROR_CODES[3]
}

var passportData = {
        "_id": "abcd",
        "name": "sreegandh",
        "dob": "1998-11-05T02:20:01.065Z",
        "gender": "male",
        "address": "12 ,abc street,xyz",
        "nationality": "indian",
        "valid_upto": "2026-01-10T02:20:01.065Z",
        "id": "XuCj6fp_F",
        "__v": 0
}

var appData1 = {
        "application_id": "V7TNUUupp",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-10T09:09:26.446Z",
        "_id": "5f08307447998d1495fc213a",
        "passport_id": "abcd",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
}

var appData2 = {
    "application_id": "hai",
    "status": "PASSPORT VERIFICATION COMPLETED , UPLOAD DOCUMENTS",
    "last_modified": new Date(Date.now()),
    "_id": "5f08307447998d1495fc213a",
    "passport_id": "abcd",
    "visa_type": "student",
    "destination": "London",
    "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
    "reason_of_travel": "studies",
    "__v": 0
}
var getAppDetailsExpectedResp = {
    "isSuccess": true,
    "code": "DOCUMENTS FETCHED ACCORDING TO STATUS SUCCESSFULLY",
    "application_data": {
        "application_id": "V7TNUUupp",
        "status": "READY FOR PASSPORT VERIFICATION",
        "last_modified": "2020-07-10T09:09:26.446Z",
        "_id": "5f08307447998d1495fc213a",
        "passport_id": "XuCj6fp_F",
        "visa_type": "student",
        "destination": "London",
        "expected_date_of_travel": "2020-10-10T18:30:00.000Z",
        "reason_of_travel": "studies",
        "__v": 0
    },
    "passport_data": {
        "_id": "5f07d051c2fd2f071270d0f3",
        "name": "sreegandh",
        "dob": "1998-11-05T02:20:01.065Z",
        "gender": "male",
        "address": "12 ,abc street,xyz",
        "nationality": "indian",
        "valid_upto": "2026-01-10T02:20:01.065Z",
        "id": "XuCj6fp_F",
        "__v": 0
    }
}

var downloadExpectedResp = {
    isSuccess: true,
    file_url: './files/V7TNUUupp/16TUCS226.JPG',
    code: 'DOCUMENTS DOWNLOADED SUCCESSFULLY'
}

var downloadErrorResp = {
    isSuccess: false,
    data: 'something went wrong',
    code: 'NO SUCH APPLICATION ID'
}

var updateExpectedResp = {
    isSuccess: true,
    code: 'APPLICATION STATUS UPDATED SUCCESSFULLY',
    data: []
  }

var uploadExpectedRes = {
    isSuccess : true,
    code : constants.SUCCESS_CODES[4],
    data : "documents uploaded successfully"
}

var uploadErrorResp ={
    isSuccess: false,
    code: 'DOCUMENT UPLOAD FAILURE',
    data: 'no documents uploaded'
  }

describe("creating a visa application", () => {
    var insertStub, mostRecentApplication;

    beforeEach(() => {
        mostRecentApplication = sinon.stub(helpers, "mostRecentApplication").returns(Promise.resolve([[]]))
        insertStub = sinon.stub(mongoUtils, "insert")
        insertStub.withArgs(sinon.match.any, creationDocReq10).returns(Promise.resolve([insertResp1]));
        insertStub.withArgs(sinon.match.any, creationDocReq20).returns(Promise.resolve(null))
        
    });

    afterEach(() => {
        insertStub.restore();
        mostRecentApplication.restore();
    })

    it("success response", async () =>{
        var expectedResponse = creationDocResp1
        var response = await services.createVisaApplication(creationDocReq1)
        expect(insertStub.calledOnce).to.be.true;
        expect(mostRecentApplication.calledOnce).to.be.true
        expect(response).to.have.all.keys(expectedResponse)
    });

    it("error response", async () => {
        var response = await services.createVisaApplication(creationDocReq2)
        expect(insertStub.calledOnce).to.be.true;
        expect(mostRecentApplication.calledOnce).to.be.true
        expect(response).to.eql(expectedResp2)
    });
});

describe("get application status", async () => {
    var findStub;

    beforeEach(() => {
        findStub = sinon.stub(mongoUtils,"findOne");
        findStub.withArgs(sinon.match.any, {application_id : "123"}).returns(Promise.resolve(appStatusRes1))
        findStub.withArgs(sinon.match.any, {application_id : "00"}).returns(Promise.resolve(undefined))
    })

    afterEach(()=> {
        findStub.restore()
    })

    it("success response", async() => {
        var response = await services.getApplicationStatus("123")
        expect(findStub.calledOnce).to.be.true
        expect(response).to.have.all.keys(appStatusExpectedRes1)
    })

    it("error response", async() => {
        var response = await services.getApplicationStatus("00")
        expect(findStub.calledOnce).to.be.true
        expect(response).to.eql(appStatusExpectedRes2)
    })
})


describe("get Applications by statusCode", async () => {
    var findStub;

    beforeEach(() => {
        findStub = sinon.stub(mongoUtils, "find")
        findStub.withArgs(1).returns(Promise.resolve(appByStatus))
        findStub.withArgs(8).returns(Promise.resolve([]))
    })

    afterEach(() => {
        findStub.restore()
    })

    it("success response", async() =>{
        var response = await services.getApplicationsByStatus(1)

        expect(findStub.calledOnce).to.be.true
        expect(response).to.have.all.keys(appByStatusResp1)
    })

    it("error response", async() => {
        var response = await services.getApplicationsByStatus(8)

        expect(findStub.calledOnce).to.be.false
        expect(response).to.eql(appByStatusResp2)
    })
});

describe("get Application Details", async() => {
    var findStub;

    beforeEach(()=> {
        findStub = sinon.stub(mongoUtils, "findOne")
        findStub.withArgs(sinon.match.any, {application_id : "123"}).returns(Promise.resolve(appData1))
        findStub.withArgs(sinon.match.any, {id : "abcd"}).returns(Promise.resolve(passportData))
        findStub.withArgs(sinon.match.any, {application_id : "00"}).returns(Promise.resolve(undefined))
    })

    afterEach(()=> {
        findStub.restore()
    })

    it("success response", async () => {
        var response = await services.getApplicationDetails("123")
        expect(findStub.callCount).to.be.eql(2)
        expect(response).to.have.all.keys(getAppDetailsExpectedResp)
    })

    it("error response", async () => {
        var response = await services.getApplicationDetails("00")
        expect(findStub.calledOnce).to.be.true
        expect(response).to.eql(appByStatusResp2)
    })
});

describe("download ", async() => {
    var findStub;

    beforeEach(() => {
        findStub = sinon.stub(mongoUtils, "findOne")
        findStub.withArgs(sinon.match.any, {file_url : "aabbccdd"}).returns(Promise.resolve(appData1))
        findStub.withArgs(sinon.match.any, {file_url  : "012"}).returns(Promise.resolve(undefined))
    })

    afterEach(()=>{
        findStub.restore()
    })

    it("success response", async () => {
        var response = await services.downloadDocuments("aabbccdd")
        expect(findStub.calledOnce).to.be.true
        expect(response).to.have.all.keys(downloadExpectedResp)
    })

    it("error response", async() => {
        var response = await services.downloadDocuments("012")
        expect(findStub.calledOnce).to.be.true
        expect(response).to.eql(downloadErrorResp)
    })
})


describe("update visa application",async () => {
    var mongoServer, visaSchema;
    beforeEach(async () => {
        mongoServer = new MongoMemoryServer.MongoMemoryServer();
        const mongoUri = await mongoServer.getUri();
        await mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });
        
        
    });

    afterEach(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });


    it("success response" , async () => {
        visaSchema =  visaModel
        var insertResp = await mongoUtils.insert(visaSchema, creationDocReq10)
        var updateResp = await services.modifyApplicationStatus(insertResp.application_id, 2)
        expect(updateResp).to.be.an('object')
        expect(updateResp).to.have.all.keys(updateExpectedResp)
    })

    it("success response 2" , async() => {
        visaSchema = visaModel
        var insertResp = await mongoUtils.insert(visaSchema, creationDocReq10)
        var updateResp = await services.modifyApplicationStatus(insertResp.application_id, 6)
        expect(updateResp).to.be.an('object')
        expect(updateResp).to.have.all.keys(updateExpectedResp)
    })
})

var filepath = '/Users/sreegandh.senthilkum/travel-easy-mongo/utils/helpers.js'

describe("upload documents" ,async() => {
   

    it("success response", async() => {
        superTest(server.app)
        .post("/traveleasy/visa_application/0c68c72d6cc1a02812a52d1bf4ac18cd812582e490fe3ab45050a250e854c3e7/documents")
        .attach("sampleFile",filepath)
        .end(function (err, res){
            console.log(res.body)
            expect(res.body).to.eql(uploadExpectedRes)
        });
    })

    it("error response ", async() => {
        superTest(server.app)
        .post("/traveleasy/visa_application/0c68c72d6cc1a02812a52d1bf4ac18cd812582e490fe3ab45050a250e854c3e7/documents")
        .end(function (err, res){
            expect(res.body).to.eql(uploadErrorResp)
        });
    })
})




