const express = require('express')
const app = express()
const fileUpload = require('express-fileupload')
const dotenv = require('dotenv')
const utils = require('./utils/mongoUtil')
const constants = require ('./constants/constants')
const controller = require ('./controllers/controller')

app.use(express.json())
dotenv.config()
app.listen(process.env.PORT)

app.use(fileUpload())


utils.connect_to_db(process.env.MONGO_URL)

app.post(constants.ROUTES.VISA_APPLICATIONS, controller.createVisaApplication)

app.get(constants.ROUTES.VISA_APPLICATION_STATUS, controller.getApplicationStatus)

app.get(constants.ROUTES.VISA_APPLICATIONS, controller.getApplicationsByStatus)

app.get(constants.ROUTES.VISA_APPLICATION, controller.getApplicationDetails)

app.post(constants.ROUTES.VISA_APPLICATION, controller.modifyApplicationStatus)

app.post(constants.ROUTES.DOCUMENT_UPLOAD, controller.uploadDocuments)

app.get(constants.ROUTES.DOCUMENT_UPLOAD , controller.downloadDocument)

module.exports = {
    app
}