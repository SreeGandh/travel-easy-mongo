const mongoose = require('mongoose')

function connect_to_db(db_url){
    
    mongoose.connect(db_url ,{ useNewUrlParser: true , useUnifiedTopology: true, useFindAndModify: false},() => {
        console.log("db connected")
    })

    var db = mongoose.connection;

    db.on('error', console.error.bind(console, 'connection error:'));
    
    db.once('open', function() {
        console.log("Connection Successful!");
    })

}

insertMany = async(model, documentJsonArray) => {
    // console.log(documentJsonArray)
     let result = await model.insertMany(documentJsonArray)
     // .then(() => {
     //     console.log("data inserted")
     // }).catch(function(err) {
     //     console.log(err)
     // })
     return result
 }

insert = async (model, document) => {
    let result = await new model(document).save()
    //console.log("insert", result)
    return result
}

findOne = async(model, filtervalue) => {
    let result = await model.findOne(filtervalue)
   // console.log("find one res", result)
    return result
}

find = async(model, filterQuery) => {
    let result = await model.find(filterQuery)
    //console.log("res", result)
    return result
}

findOneAndUpdate = async (model, filter_query, update_query) => {
    let result = await model.findOneAndUpdate(filter_query, update_query,{
        new : true
    })
    return result 
}

module.exports = {
    connect_to_db,
    insertMany,
    insert,
    findOneAndUpdate,
    find,
    findOne
}