const visaModel = require('../models/visaApplication')

function getDifferenceBetweenDays(date1 , date2){
    let first_date = new Date(date1); 
    let sec_date = new Date(date2);
    // console.log(date1 , " + " ,date2)
    // console.log("first" , first_date)
    // console.log("seco" , sec_date)

    let diff_in_time = first_date.getTime() - sec_date.getTime()

    //console.log("time_dif" , diff_in_time)

    let diff_in_days = diff_in_time / (1000 * 3600 * 24)

    //console.log("diff_days", diff_in_days)

    return parseInt(diff_in_days)
}

mostRecentApplication = async () => {
    application = await visaModel.aggregate([
    {
        $match :{
            passport_id : applicationDetails.passport_id
        }
    },
    {
        $sort : {
            last_modified : -1
        }
    },
    {
        $limit : 1
    }
    ])

    return application
}

module.exports = {
    getDifferenceBetweenDays,
    mostRecentApplication
}